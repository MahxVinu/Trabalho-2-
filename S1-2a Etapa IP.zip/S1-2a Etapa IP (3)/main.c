#include <stdio.h>
#include <stdlib.h>
#include "pacientes.h"
#include <string.h>
#include "Atendimentos.h"
#include <locale.h>



// Enum for menu options
enum MainMenuOptions {
    PACIENTE = 1,
    ATENDIMENTO,
    SAIR
};

// Enum for paciente menu options
enum PacienteMenuOptions {
    INSERIR = 1,
    ALTERAR,
    REMOVER,
    IMPRIMIR_DADOS,
    LISTAR_TIPO_SANGUINEO,
    LISTAR_CONSULTA,
    LISTAR_TODOS,
    LISTAR_ALFABETICA,
    SALVARP,
    VOLTAR_PACIENTE
};
enum Opcoes_Atendimento{
    VOLTAR,
    INSERIR_ATENDIMENTO,
    LISTAR_ATENDIMENTOS,
    REMOVER_ATENDIMENTO,
    MOSTRAR_ATENDIMENTOS_PACIENTE,
    MOSTRAR_DADOS_ATENDIMENTO,
    ALTERAR_ATENDIMENTO,
    SOMA_CONSULTAS_PAGAS,
    ORDENAR_POR_DATA,
    SOMAR_PRECO_POR_DATA,
    SOMA_CONSULTAS_EM_INTERVALO,
};


// variaveis e funçoes de controle de atendimentos
int opcao;
int valor;
float soma;
char arquivo[] = {"Atendimentos"};
//Atendimento *resposta;
Lista listaAtendimentos;
struct VetorDinamico pacientes;


// Prototypes
void menu();
void menuP();
int menuAtendimento();
//void limparBufferEntrada();
void salvarDados();
int realizarAlteracoesAntesDeSair();
int inserirAtendimento(Lista *lista);

int main()
{
    setlocale(LC_ALL,"Portuguese");
    inicializarVetor(&pacientes, 10);

    carregarDeArquivo(&pacientes,"pacientes.txt");

    //Atendimento *resposta;



    carregar_lista(&listaAtendimentos,arquivo);
    controle(listaAtendimentos);

    srand(time(NULL));

    menu();

    return 0;
}

// Menu Principal
void menu()
{
    printf("-------------------------------------------\n");
    printf("              CLÍNICA AJALMAR              \n");
    printf("-------------------------------------------\n");
    printf("          \n\tDIGITE SUA OPÇÃO:\n");
    printf("\n\t1 - PACIENTES\n");
    printf("\t2 - ATENDIMENTOS\n");
    printf("\t4 - SAIR\n");
    printf("-------------------------------------------\n");

    int opcm = 0;
    scanf("%d", &opcm);
    limparbuffer();

    switch (opcm) {
        case PACIENTE:
            menuP();
            break;
        case ATENDIMENTO:
            menuAtendimento();
            menu();
            break;
        case SAIR:
        {
            int i = realizarAlteracoesAntesDeSair();

            if (i == 1) {
                salvarDados();
                exit(0);
            }
            else if (i == 0)
            {
                exit(0);
            }
            else {
                printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
                printf("OPÇÃO INVÁLIDA. INSIRA UM CÓDIGO VÁLIDO.\n");
                printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
                menu();
            }
        }
    }
}

// Menu do Paciente
void menuP()
{
    printf("\n");
    printf("-------------- PACIENTES --------------\n");
    printf("          \nDIGITE SUA OPÇÃO:\n");
    printf("\n\t1 - INSERIR NOVO PACIENTE\n");
    printf("\t2 - ALTERAR PACIENTE EXISTENTE\n");
    printf("\t3 - EXCLUIR UM PACIENTE\n");
    printf("\t4 - CHECAR DADOS PELO CÓDIGO DO PACIENTE\n");
    printf("\t5 - MOSTRAR PACIENTES DE UM TIPO SANGUÍNEO\n");
    printf("\t6 - MOSTRAR PACIENTES PELO DIA DO ATENDIMENTO\n");
    printf("\t7 - MOSTRAR TODOS OS PACIENTES\n");
    printf("\t8 - MOSTRAR PACIENTES EM ORDEM ALFABÉTICA\n");
    printf("\t9 - SALVAR ALTERAÇÕES\n");
    printf("\t10 - VOLTAR\n");
    printf("--------------------------------------------------------\n");

    int opc = 0;
    scanf("%d", &opc);
    limparbuffer();


    switch (opc) {
        case INSERIR:
            inserir(&pacientes);
            menuP();
            break;
        case ALTERAR:
            alterarPaciente(&pacientes);
            menuP();
            break;
        case REMOVER: {
            char codigo[12];
            printf("DIGITE O CÓDIGO:");
            fgets(codigo, sizeof(codigo), stdin);
            //Remove o caractere de nova linha,se presente
            codigo[strcspn(codigo, "\n")] = '\0';
            //converte a string para um numero inteiro usando atoi
            int codPaciente = atoi(codigo);
            ExcluirAtendimentoPorCodP(&listaAtendimentos, codPaciente);
            excluirPacientePorCodigo(&pacientes, codigo);
            menuP();
            break;
        }
        case IMPRIMIR_DADOS:
        {
            char* cd = malloc(10);  // Aloca dinamicamente espaço para o TS


            printf("=====================================\n");
            printf("INSIRA O CÓDIGO DO PACIENTE: \n");
            printf("=====================================\n");
            fgets(cd, 10, stdin);
            cd[strcspn(cd, "\n")] = '\0';

            int indice = -1;

            for (int i = 0; i < pacientes.tamanho; ++i)
            {
                if (pacientes.dados[i].codigo != NULL && strcmp(cd, pacientes.dados[i].codigo) == 0)
                {
                    indice = i;
                    break;
                }
            }

            if (indice == -1)
            {
                printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
                printf("NÃO EXISTE PACIENTES COM ESSE CÓDIGO\n");
                printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
            }

            else
            {
                imprimirPacientesPorCodigo(&pacientes,cd);
            }

            free(cd);
            menuP();
            break;
        }



        case LISTAR_TIPO_SANGUINEO:
        {
            char* ts = malloc(5);  // Aloca dinamicamente espaço para o TS


            printf("=====================================\n");
            printf("INSIRA O TIPO SANGUÍNEO DO PACIENTE: \n");
            printf("=====================================\n");
            fgets(ts, 5, stdin);
            ts[strcspn(ts, "\n")] = '\0';

            int indice;

            for (int i = 0; i < pacientes.tamanho; ++i)
            {
                if (pacientes.dados[i].ts != NULL && strcmp(ts, pacientes.dados[i].ts) == 0)
                {
                    indice = 1;
                    break;
                }
                else indice = -1;
            }

            if (indice == -1)
            {
                printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
                printf("NÃO EXISTEM PACIENTES COM ESSE TIPO SANGUÍNEO!\n");
                printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
            }

            else
            {
                imprimirPacientesPorTipoSanguineo(&pacientes,ts);
            }

            free(ts);

            menuP();
            break;
        }

        case LISTAR_TODOS:
            imprimir_pacientes(&pacientes);
            menuP();
            break;

        case LISTAR_ALFABETICA:
            imprimir_ordem(&pacientes);
            menuP();
            break;
        case SALVARP:
            salvarEmArquivo(&pacientes,"pacientes.txt");
            printf("\nALTERAÇÕES SALVAS!\n");
            menuP();
            break;

        case VOLTAR_PACIENTE:
            menu();
            break;
        case LISTAR_CONSULTA:
           // carregar_lista(&listaAtendimentos,arq);
            Pacientes_com_consulta_naData(&listaAtendimentos,&pacientes);
            menu();
            break;

        default:
            printf("OPÇÃO INVÁLIDA\n");
            break;

    }
}
int menuAtendimento(){
Atendimento  *resposta;



    do {
        printf("\n");
        printf("-------------- ATENDIMENTOS --------------\n\n");
        printf("           DIGITE SUA OPÇÃO:\n\n");
        printf("\t0 - VOLTAR\n");
        printf("\t1 - INSERIR NOVO ATENDIMENTO\n");
        printf("\t2 - MOSTRAR TODOS OS ATENDIMENTOS\n");
        printf("\t3 - EXCLUIR ATENDIMENTO\n");
        printf("\t4 - CHECAR DADOS PELO CÓDIGO DO PACIENTE\n");
        printf("\t5 - CHECAR DADOS PELO CÓDIGO DO ATENDIMENTO\n");
        printf("\t6 - ALTERAR ATENDIMENTO\n");
        printf("\t7 - MOSTRAR SOMA DAS CONSULTAS PAGAS POR UM PACIENTE\n");
        printf("\t8 - MOSTRAR ATENDIMENTOS ORDENADOS POR DATA\n");
        printf("\t9 - MOSTRAR A SOMA DAS CONSULTAS PAGAS PARA OS ATENDIMENTOS DE UMA DETERMINADA DATA\n");
        printf("\t10 - MOSTRAR A SOMA DAS CONSULTAS PAGAS DENTRO DE UM INTERVALO DE DATAS\n");
        printf("--------------------------------------------------------------------------------------------------\n");
        scanf("%d",&opcao);
        switch (opcao) {
            case VOLTAR:
                printf("\n\tDESEJA SALVAR AS ALTERAÇÕES REALIZADAS?\n");
                printf("\n\t1 - SIM\n\t2 - NAO\n");
                scanf("%d",&valor);
                while(1){
                    if(valor == 1 || valor == 2)
                        break;
                    scanf("%d",&valor);
                    limparbuffer();
                }
                if(valor == 1) {
                    salvar(&listaAtendimentos, arquivo);
                }

                break;


            case INSERIR_ATENDIMENTO:
                valor = inserirAtendimento(&listaAtendimentos);
                if(valor == 1)
                    printf("\nO CODIGO DE ATENDIMENTO JÁ EXISTE\n");
                else if(valor == 2)
                    printf("\nA CONSULTA JÁ FOI MARCADA!\n");
                else if(valor == 4){
                    printf("\nNÃO EXISTE PACIENTE COM ESSE CÓDIGO!\n");
                }
                else{
                    printf("\n\tATENDIMENTO INSERIDO COM SUCESSO!\n");
                }

                break;

            case  LISTAR_ATENDIMENTOS:
                listarAtendimentos(listaAtendimentos);
                break;

            case REMOVER_ATENDIMENTO:
                printf("INSIRA O CÓDIGO DO ATENDIMENTO QUE SERÁ REMOVIDO:\n");
                scanf("%d",&valor);
                limparbuffer();
                resposta = ExcluirAtendimento(&listaAtendimentos,valor);
                if(resposta){
                    resposta->alterado = 3;
                    printf("\nATENDIMENTO REMOVIDO: %d\n",resposta->codigoA);
                    free(resposta);
                    salvar(&listaAtendimentos,arquivo);
                }
                else{
                    printf("CÓDIGO DE ATENDIMENTO INEXISTENTE!\n");
                }
                break;

            case MOSTRAR_ATENDIMENTOS_PACIENTE:
                printf("INSIRA O CÓDIGO DO PACIENTE QUE SERÁ PESQUISADO:\n");
                scanf("%d",&valor);
                imprimir_por_codigoP(&listaAtendimentos,valor);
                break;

            case MOSTRAR_DADOS_ATENDIMENTO:
                printf("INSIRA O CÓDIGO DO ATENDIMENTO QUE SERÁ PESQUISADO:\n");
                scanf("%d",&valor);
                imprimir_por_codigoA(&listaAtendimentos,valor);
                break;

            case ALTERAR_ATENDIMENTO:
                printf("INSIRA O CÓDIGO DO ATENDIMENTO QUE SERÁ ALTERADO:\n");
                scanf("%d",&valor);
                resposta = alterarAtendimento(&listaAtendimentos,valor);
                if(resposta){

                    printf("\nALTERAÇÕES REALIZADAS COM SUCESSO!\n");
                }
                else{
                    printf("\nCÓDIGO DE ATENDIMENTO NÃO ENCONTRADO!\n");

                }
                break;

            case SOMA_CONSULTAS_PAGAS:
                printf("DIGITE O CÓDIGO DO PACIENTE:\n");
                scanf("%d",&valor);
                Soma_precoConsultasP(&listaAtendimentos,valor);
                break;



            case ORDENAR_POR_DATA:
                imprimirPorOrdemData(&listaAtendimentos);
                break;

            case SOMAR_PRECO_POR_DATA:
                soma =  soma_Preco_Por_Data(&listaAtendimentos);
                if(soma){
                    printf("\n\tSOMA DAS CONSULTAS: $%.2f\n",soma);
                }
                else {
                    printf("\nNENHUMA CONSULTA FOI REALIZADA NESSA DATA\n");
                }
                break;

            case SOMA_CONSULTAS_EM_INTERVALO:
                soma_consultas_em_intervalo(&listaAtendimentos);
                break;

            default:
                printf("\nOPÇÃO INVÁLIDA!\n");
                break;

        }
    }while(opcao != 0);


    return 0;
}







// Função para salvar os dados em um arquivo
void salvarDados()
{
    salvarEmArquivo(&pacientes, "pacientes.txt");
    printf("DADOS SALVOS COM SUCESSO!\n");
}

// Função para perguntar ao usuário se deseja realizar alterações antes de sair
int realizarAlteracoesAntesDeSair()
{
    printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
    printf("         DESEJA REALIZAR ALTERAÇÕES ANTES DE SAIR?\n");
    printf("                 (1 - SIM 0 - NÃO):\n");
    printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
    int resposta;
    scanf("%d", &resposta);
    limparbuffer();
    return resposta;
}

int inserirAtendimento(Lista *lista) {
    Atendimento *aux, *novo = malloc(sizeof(Atendimento));
    int cod, codP;
    int retorno;
    if (novo) {
        printf("INFORME OS DADOS DO ATENDIMENTO:\n");
        cod = gerador();
        retorno = verifica_CodA(cod, lista);
        if (retorno) {
            return retorno;
        }
        printf("\nCÓDIGO DO PACIENTE:\n");
        scanf("%d", &codP);
        limparbuffer();
        const char *ScodP = transforma_cod_para_string(codP);
        retorno = verificaCodigoPaciente(&pacientes, ScodP);
        if (retorno == 4) {
            return retorno;
        }
        novo->codigoP = codP;

        printf("\nTIPO DE ATENDIMENTO:\n");
        inserir_tipo(novo);

        printf("\nSTATUS DE ATENDIMENTO (OU TECLE ENTER PARA VAZIO):\n");
        inserir_status(novo);



        char buffer[256];  // Buffer para armazenar a entrada do usuário

        printf("\nPREÇO DO ATENDIMENTO (OU TECLE ENTER PARA VAZIO):\n");

        // Obtém a entrada do usuário e armazena em buffer
        fgets(buffer, sizeof(buffer), stdin);

        // Se o usuário pressionar Enter, atribua um preço vazio
        if (buffer[0] == '\n') {
            novo->preco = 0.0;  // Ou outro valor padrão desejado
        } else {
            // Converte a string para um número de ponto flutuante usando sscanf
            sscanf(buffer, "%f", &novo->preco);
        }

        limparbuffer();  // Limpar o buffer de entrada



        time_t data;
        //Struct para armazenar a data do atendimento
        struct tm data_atendimento_tm = {0};
        printf("\nDATA DE ATENDIMENTO(DD/MM/AAAA):\n");
        scanf("%d/%d/%d", &data_atendimento_tm.tm_mday, &data_atendimento_tm.tm_mon, &data_atendimento_tm.tm_year);
        limparbuffer();
        data_atendimento_tm.tm_mon--; // Ajuste do mes para começar do zero (janeiro é zero)
        data_atendimento_tm.tm_year -= 1900; // Ajuste do ano para o formato correto

        //converte a data do atendimento para time_t
        data = mktime(&data_atendimento_tm);
        novo->data_atendimentos = data; //Armazena a data do atendimento como time_t
        retorno = consultaMarcadaNaData(lista, novo->codigoP, novo->data_atendimentos);
        if (retorno) {
            return retorno;
        }
        novo->codigoA = cod;
        printf("\nCÓDIGO DO ATENDIMENTO:  %d\n", novo->codigoA);


        // É o primeiro?
        if (lista->inicio == NULL) {
            lista->inicio = novo;
            novo->proximo = NULL;
        } else {
            aux = lista->inicio;
            while (aux->proximo) {
                aux = aux->proximo;
            }
            aux->proximo = novo;
            novo->proximo = NULL;

        }
        lista->tam++;
    }

    else{
        printf("ERRO AO ALOCAR MEMÓRIA!");
        exit(1);
    }

    return retorno;
}




