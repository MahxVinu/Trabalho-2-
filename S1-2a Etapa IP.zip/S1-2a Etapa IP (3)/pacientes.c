#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include "pacientes.h"
#include "Atendimentos.h"


int compararPacientes(const void *a, const void *b) {
    const struct paciente *pacienteA = (const struct paciente *)a;
    const struct paciente *pacienteB = (const struct paciente *)b;
    return strcmp(pacienteA->nome, pacienteB->nome);
}

// Função para converter uma string para maiúsculas
void converterParaMaiusculas(char *str)
{
    for (int i = 0; str[i] != '\0'; i++)
    {
        str[i] = toupper(str[i]);
    }
}

// Função pra liberar memoria usada pelo paciente
void liberarPaciente(struct paciente *p)
{
    free(p->nome);
    free(p->RG);
    free(p->cpf);
    free(p->ts);
    free(p->rh);
    free(p->end);
}

// Função pra liberar a memoria de todos os pacientes no vetor
void liberarMemoria(struct VetorDinamico *paciente)
{
    for (int i = 0; i < paciente->tamanho; ++i)
    {
        liberarPaciente(&paciente->dados[i]);
    }
    free(paciente->dados);
}

void inicializarVetor(struct VetorDinamico *vetor, int capacidadeInicial) {
    vetor->dados = (struct paciente *)malloc(capacidadeInicial * sizeof(struct paciente));
    if (vetor->dados == NULL) {
        printf("Erro ao alocar memoria.\n");
        exit(1);
    }

    // Allocate memory for strings in each paciente
    for (int i = 0; i < capacidadeInicial; ++i) {
        vetor->dados[i].codigo = NULL;
        vetor->dados[i].nome = NULL;
        vetor->dados[i].RG = NULL;
        vetor->dados[i].cpf = NULL;
        vetor->dados[i].ts = NULL;
        vetor->dados[i].rh = NULL;
        vetor->dados[i].end = NULL;
    }

    vetor->tamanho = 0;
    vetor->capacidade = capacidadeInicial;
}
void adicionarElemento(struct VetorDinamico *vetor, struct paciente paciente) {
    if (vetor->tamanho == vetor->capacidade) {
        vetor->capacidade *= 2;
        vetor->dados = (struct paciente *)realloc(vetor->dados, vetor->capacidade * sizeof(struct paciente));
        if (vetor->dados == NULL) {
            printf("Erro na realocação de memória.\n");
            exit(1);
        }
    }

    vetor->dados[vetor->tamanho] = paciente;
    vetor->tamanho++;
}

// Função para ler a data de nascimento
void lerDataNascimento(struct tm *dataNascimento)
{
    printf("=====================================\n");
    printf("Insira a data de nascimento (Modelo: DD MM YYYY): \n");
    printf("=====================================\n");

    while (1)
    {
        char data_buffer[20];
        fgets(data_buffer, sizeof(data_buffer), stdin);
        data_buffer[strcspn(data_buffer, "\n")] = '\0';

        // Verifica se a linha lida contém apenas a nova linha (\n)
        if (strlen(data_buffer) > 0)
        {
            // Converte a string para uma estrutura tm
            if (sscanf(data_buffer, "%d %d %d", &dataNascimento->tm_mday, &dataNascimento->tm_mon, &dataNascimento->tm_year) == 3)
            {
                // Ajusta os valores para o formato de struct tm
                dataNascimento->tm_year -= 1900;
                dataNascimento->tm_mon -= 1;

                // Verificações adicionais
                if (dataNascimento->tm_year < 0 || dataNascimento->tm_mon < 0 || dataNascimento->tm_mday < 1 ||
                    dataNascimento->tm_mon > 11 || dataNascimento->tm_mday > 31)
                {
                    printf("Data inválida. Insira novamente a data no formato (DD MM YYYY): \n");
                }
                else
                {
                    break; // Sai do loop se a data for válida
                }
            }
            else
            {
                printf("Formato inválido. Insira novamente a data no formato (DD MM YYYY): \n");
            }
        }
    }
}

// Função para ler o tipo sanguíneo
void lerTipoSanguineo(char *tipoSanguineo)
{
    printf("=====================================\n");
    printf("Escolha o tipo sanguíneo (A, B, O, AB)\n");
    printf("=====================================\n");

    // Loop até que uma entrada válida seja fornecida
    while (1)
    {
        // Usando fgets para ler a linha completa
        char buffer[256];  // Tamanho do buffer ajustável conforme necessário
        fgets(buffer, sizeof(buffer), stdin);

        // Remover o caractere de nova linha (Enter)
        buffer[strcspn(buffer, "\n")] = '\0';

        // Verificar se a entrada é vazia (apenas Enter)
        if (strlen(buffer) == 0)
        {
            *tipoSanguineo = '\0'; // Atribui uma string vazia
            break;
        }
        else
        {
            *tipoSanguineo = toupper(buffer[0]); // Converte para maiúscula
            if (*tipoSanguineo == 'A' || *tipoSanguineo == 'B' || *tipoSanguineo == 'O' || strcmp(tipoSanguineo, "AB") == 0)
            {
                // Entrada válida, sai do loop
                break;
            }
            else
            {
                printf("Opção inválida. Escolha entre A, B, O ou AB: ");
            }
        }
    }
}
// Função para ler o fator RH
void lerFatorRH(char *fatorRH)
{
    printf("=====================================\n");
    printf("Escolha o fator RH (+, - ou Enter para vazio): \n");
    printf("=====================================\n");

    // Usando fgets para ler a linha completa
    char buffer[256];  // Tamanho do buffer ajustável conforme necessário
    fgets(buffer, sizeof(buffer), stdin);

    // Remover o caractere de nova linha (Enter)
    buffer[strcspn(buffer, "\n")] = '\0';

    // Verificar se a entrada é vazia (apenas Enter)
    if (strlen(buffer) == 0)
    {
        *fatorRH = '\0'; // String vazia
    }
    else
    {
        *fatorRH = toupper(buffer[0]); // Converte para maiúscula
        if (*fatorRH != '+' && *fatorRH != '-')
        {
            printf("Opção inválida. Escolha entre +, - ou Enter para vazio: ");
            lerFatorRH(fatorRH); // Chamada recursiva para obter uma entrada válida
            return;
        }
    }
}


// Insere o paciente
struct VetorDinamico *inserir(struct VetorDinamico *paciente)
{
    struct paciente np;

    while(1)
    {
        // Pedir nome do paciente
        char nome[255];
        printf("=====================================\n");
        printf("Insira o nome do Paciente: \n");
        printf("=====================================\n");
        fgets(nome, sizeof(nome), stdin);
        // Remover a nova linha do final
        nome[strcspn(nome, "\n")] = '\0';


        // Converter para maiúsculas
        converterParaMaiusculas(nome);

        if (strlen(nome) > 0 && contemApenasLetras(nome)) {
            np.nome = strdup(nome);
            break;
        }
        else
            printf("Insira um nome válido.\n");
    }



    //pedir rg
    char buffer[12];

    printf("=====================================\n");
    printf("Insira o RG do paciente : \n");
    printf("=====================================\n");
    fgets(buffer, sizeof(buffer), stdin);
    // Remover a nova linha do final
    buffer[strcspn(buffer, "\n")] = '\0';

    // Converter para maiúsculas
    converterParaMaiusculas(buffer);

    // Se a linha lida contiver apenas a nova linha (\n), atribui um valor vazio ou nulo
    if (buffer[0] == '\0' || buffer[0] == '\n' && contemApenasNumeros(buffer))
    {
        np.RG = strdup("");
    }
    else if ( contemApenasNumeros(buffer))
    {
        np.RG = strdup(buffer);
    }
    else
        printf("Insira um RG válido (apenas números)");


    // Ler cpf
    while (1)
    {
        char cpf_buffer[20];

        while (1)
        {
            // Pedir CPF do paciente
            printf("=====================================\n");
            printf("Insira o CPF do paciente: \n");
            printf("=====================================\n");
            fgets(cpf_buffer, sizeof(cpf_buffer), stdin);
            cpf_buffer[strcspn(cpf_buffer, "\n")] = '\0';

            // Verificar se a string contém apenas dígitos e não está vazia
            if (contemApenasNumeros(cpf_buffer) && strlen(cpf_buffer) > 0)
            {
                np.cpf = strdup(cpf_buffer);
                break;
            }
            else
            {
                printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
                printf("O CPF deve conter apenas números e não pode estar vazio, tente novamente.\n");
                printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
            }
        }

        int isDuplicate = 0;

        for (int i = 0; i < paciente->tamanho; ++i)
        {
            if (paciente->dados[i].cpf != NULL && strcmp(cpf_buffer, paciente->dados[i].cpf) == 0)
            {
                isDuplicate = 1;
                break;
            }
        }
        if (isDuplicate)
        {
            printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
            printf("O CPF já foi inserido, tente novamente.\n");
            printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
            printf("\n");
        }

        if (!isDuplicate)
        {
            break;
        }
    }

    //pedir tipo sanguíneo
    char tipoSanguineo;
    lerTipoSanguineo(&tipoSanguineo);
    np.ts = malloc(3);
    snprintf(np.ts, 3, "%c", tipoSanguineo);

    //pedir fator rh
    char fatorRH;
    lerFatorRH(&fatorRH);
    np.rh = malloc(2);
    snprintf(np.rh, 2, "%c", fatorRH);

    lerDataNascimento(&np.dataNascimento);

    //pedir edenreço
    char bufferEnd[255];
    printf("=====================================\n");
    printf("Insira o endereco: \n");
    printf("=====================================\n");
    fgets(bufferEnd, sizeof(bufferEnd), stdin);

    // Remover a nova linha do final
    bufferEnd[strcspn(bufferEnd, "\n")] = '\0';

    // Converter para maiúsculas
    converterParaMaiusculas(bufferEnd);

    // Se a linha lida contiver apenas a nova linha (\n), atribui um valor vazio ou nulo
    if (bufferEnd[0] == '\0' || bufferEnd[0] == '\n') {
        np.end = strdup("");
    } else {
        np.end = strdup(bufferEnd);
    }



    int codigo = rand();
    char codigostr[8];

    snprintf(codigostr, sizeof(codigostr), "%d", codigo);
    np.codigo = strdup(codigostr);
    printf("=====================================\n");
    printf("Paciente adicionado.    Codigo: %s.\n", codigostr);
    printf("  Pressione ENTER para continuar...\n");
    printf("=====================================\n");
    while(1)
    {
        fgets(buffer, sizeof(buffer), stdin);
        // Se a linha lida contiver apenas a nova linha (\n), atribui um valor vazio ou nulo
        if (buffer[0] == '\0' || buffer[0] == '\n')
        {
            // Adiciona o paciente ao vetor dinâmico
            adicionarElemento(paciente, np);
            return paciente;
        }

        else
        {
            printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
            printf("           Pressione Enter!\n");
            printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
        }

    }
}

// Função para alterar CPF
void alterarCPF(struct VetorDinamico *paciente, int indice)
{
    char novoCPF[20];
    printf("Insira o novo CPF: ");
    fgets(novoCPF, sizeof(novoCPF), stdin);
    novoCPF[strcspn(novoCPF, "\n")] = '\0';

    // Verificar se o novo CPF já existe
    int existeCPF = 0;
    for (int i = 0; i < paciente->tamanho; i++)
    {
        if (i != indice && strcmp(paciente->dados[i].cpf, novoCPF) == 0)
        {
            existeCPF = 1;
            break;
        }
    }

    if (existeCPF)
    {
        printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
        printf("CPF %s ja existe, nao foi posivel alterar.\n", novoCPF);
        printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
    }
    else
    {
        // Liberar a memória do CPF antigo
        free(paciente->dados[indice].cpf);

        // Alocar memória para o novo CPF
        paciente->dados[indice].cpf = strdup(novoCPF);

        printf("CPF alterado com sucesso.\n");
    }
}

// Função para buscar um paciente pelo CPF
int buscarPacientePorCPF(const struct VetorDinamico *paciente, const char *cpf)
{
    for (int i = 0; i < paciente->tamanho; ++i)
    {
        if (paciente->dados[i].cpf != NULL && strcmp(cpf, paciente->dados[i].cpf) == 0)
        {
            return i; // Retorna o índice do paciente encontrado
        }
    }
    return -1; // Retorna -1 se o paciente não for encontrado
}
// Enumeração para representar as opções de alteração


// Função para alterar dados de um paciente
void alterarPaciente(struct VetorDinamico *paciente)
{
    char cpf_buffer[20];
    printf("=====================================\n");
    printf("Insira o CPF do paciente que deseja alterar: \n");
    printf("=====================================\n");
    fgets(cpf_buffer, sizeof(cpf_buffer), stdin);
    cpf_buffer[strcspn(cpf_buffer, "\n")] = '\0';

    int indice = buscarPacientePorCPF(paciente, cpf_buffer);

    if (indice == -1)
    {
        printf("Paciente com CPF %s nao encontrado.\n", cpf_buffer);
    }
    else
    {
        printf("=====================================\n");
        printf("Escolha o que deseja alterar:\n");
        printf("%d. Nome\n", ALTERAR_NOME);
        printf("%d. RG\n", ALTERAR_RG);
        printf("%d. Tipo Sanguineo\n", ALTERAR_TIPO_SANGUINEO);
        printf("%d. Fator RH\n", ALTERAR_FATOR_RH);
        printf("%d. Endereco\n", ALTERAR_ENDERECO);
        printf("%d. Data de Nascimento\n", ALTERAR_DATA_NASCIMENTO);
        printf("%d. CPF\n", ALTERAR_CPF);  // Adicionando a opção para alterar CPF
        printf("%d. Cancelar\n", CANCELAR_ALTERACAO);
        printf("=====================================\n");

        int opcao;
        scanf("%d", &opcao);
        getchar(); // Limpar o buffer de entrada

        switch (opcao)
        {
            case ALTERAR_NOME:
                printf("Insira o novo nome: ");
                fgets(paciente->dados[indice].nome, sizeof(paciente->dados[indice].nome), stdin);
                paciente->dados[indice].nome[strcspn(paciente->dados[indice].nome, "\n")] = '\0';
                break;
            case ALTERAR_RG:
                printf("Insira o novo RG: ");
                fgets(paciente->dados[indice].RG, sizeof(paciente->dados[indice].RG), stdin);
                paciente->dados[indice].RG[strcspn(paciente->dados[indice].RG, "\n")] = '\0';
                break;
            case ALTERAR_TIPO_SANGUINEO:
                printf("Insira o novo tipo sanguíneo: ");
                fgets(paciente->dados[indice].ts, sizeof(paciente->dados[indice].ts), stdin);
                paciente->dados[indice].ts[strcspn(paciente->dados[indice].ts, "\n")] = '\0';
                break;
            case ALTERAR_FATOR_RH:
                printf("Insira o novo fator RH: ");
                fgets(paciente->dados[indice].rh, sizeof(paciente->dados[indice].rh), stdin);
                paciente->dados[indice].rh[strcspn(paciente->dados[indice].rh, "\n")] = '\0';
                break;
            case ALTERAR_ENDERECO:
                printf("Insira o novo endereço: ");
                fgets(paciente->dados[indice].end, sizeof(paciente->dados[indice].end), stdin);
                paciente->dados[indice].end[strcspn(paciente->dados[indice].end, "\n")] = '\0';
                break;
            case ALTERAR_DATA_NASCIMENTO:
                printf("Insira a nova data de nascimento (DD MM YYYY): ");
                lerDataNascimento(&paciente->dados[indice].dataNascimento);
                break;
            case ALTERAR_CPF:
                // Função para alterar CPF
                alterarCPF(paciente, indice);
                break;
            case CANCELAR_ALTERACAO:
                printf("Operação cancelada.\n");
                break;
            default:
                printf("Opção inválida.\n");
        }
    }
}
// Função modificada para trabalhar com VetorDinamico
void imprimir_pacientes(const struct VetorDinamico *paciente) {
    // Título
    printf("%-20s%-15s%-15s%-9s%-20s%-25s%-20s\n", "Nome", "RG", "CPF", "T.S", "Fator RH", "Endereco", "Codigo");
    printf("========================================================================================================================\n");

    // Dados dos pacientes
    for (int i = 0; i < paciente->tamanho; i++) {

        printf("%-20s%-15s%-15s%-9s%-20s%-25s%-20s\n",
               paciente->dados[i].nome, paciente->dados[i].RG, paciente->dados[i].cpf,
               paciente->dados[i].ts, paciente->dados[i].rh, paciente->dados[i].end,
               paciente->dados[i].codigo);

        printf("Data Nascimento: %02d/%02d/%04d\n",
               paciente->dados[i].dataNascimento.tm_mday,
               paciente->dados[i].dataNascimento.tm_mon + 1,
               paciente->dados[i].dataNascimento.tm_year + 1900);
        printf("========================================================================================================================\n");
    }
}

// Função para salvar os dados dos pacientes em um arquivo texto
void salvarEmArquivo(const struct VetorDinamico *paciente, const char *nomeArquivo)
{
    FILE *arquivo = fopen(nomeArquivo, "w");

    if (arquivo == NULL)
    {
        printf("Erro ao abrir o arquivo para escrita.\n");
        exit(1);
    }

    // Escreve os dados dos pacientes no arquivo
    for (int i = 0; i < paciente->tamanho; i++)
    {
        fprintf(arquivo, "%s;%s;%s;%s;%s;%s;%s;%d/%d/%d\n",
                paciente->dados[i].codigo, paciente->dados[i].nome, paciente->dados[i].RG,
                paciente->dados[i].cpf, paciente->dados[i].ts, paciente->dados[i].rh,
                paciente->dados[i].end,
                paciente->dados[i].dataNascimento.tm_mday,
                paciente->dados[i].dataNascimento.tm_mon + 1,
                paciente->dados[i].dataNascimento.tm_year + 1900);
    }

    fclose(arquivo);
}

/// Função para carregar dados dos pacientes de um arquivo texto
void carregarDeArquivo(struct VetorDinamico *paciente, const char *nomeArquivo)
{
    FILE *arquivo = fopen(nomeArquivo, "r");

    if (arquivo == NULL)
    {
        // O arquivo não existe, então tenta criar
        printf("O arquivo %s não existe. Criando o arquivo...\n", nomeArquivo);

        arquivo = fopen(nomeArquivo, "w");

        if (arquivo == NULL)
        {
            // Não foi possível criar o arquivo
            printf("Erro ao criar o arquivo %s.\n", nomeArquivo);
            return;
        }

        // Fecha o arquivo recém-criado
        fclose(arquivo);

        // Agora, reabre o arquivo para leitura
        arquivo = fopen(nomeArquivo, "r");
    }

    char linha[512]; // Ajuste o tamanho conforme necessário

    while (fgets(linha, sizeof(linha), arquivo) != NULL)
    {
        struct paciente np;

        // Utilize a função sscanf para extrair os dados da linha e atribuir ao paciente np
        if (sscanf(linha, "%m[^;];%m[^;];%m[^;];%m[^;];%m[^;];%m[^;];%m[^;];%d/%d/%d",
                   &np.codigo, &np.nome, &np.RG, &np.cpf, &np.ts, &np.rh, &np.end,
                   &np.dataNascimento.tm_mday, &np.dataNascimento.tm_mon, &np.dataNascimento.tm_year) == 10)
        {
            // Ajuste conforme necessário para lidar com os dados lidos
            np.dataNascimento.tm_mon -= 1;
            np.dataNascimento.tm_year -= 1900;

            adicionarElemento(paciente, np);
        }
        else
        {
            printf("Erro ao ler a linha: %s\n", linha);
        }
    }

    fclose(arquivo);
}




// Função para imprimir pacientes com um determinado tipo sanguíneo
void imprimirPacientesPorTipoSanguineo(const struct VetorDinamico *paciente, const char *tipoSanguineo)
{
    printf("Pacientes com tipo sanguineo %s:\n", tipoSanguineo);

    int pacientesEncontrados = 0;

    // Título
    printf("%-20s%-15s%-15s%-9s%-20s%-25s%-20s\n", "Nome", "RG", "CPF", "T.S", "Fator RH", "Endereco", "Codigo");
    printf("========================================================================================================================\n");

    for (int i = 0; i < paciente->tamanho; i++)
    {
        // Comparar tipos sanguíneos, ignorando maiúsculas/minúsculas
        if (strcasecmp(paciente->dados[i].ts, tipoSanguineo) == 0)
        {
            pacientesEncontrados++;

            printf("%-20s%-15s%-15s%-9s%-20s%-25s%-20s\n",
                   paciente->dados[i].nome, paciente->dados[i].RG, paciente->dados[i].cpf,
                   paciente->dados[i].ts, paciente->dados[i].rh, paciente->dados[i].end,
                   paciente->dados[i].codigo);

            printf("Data Nascimento: %02d/%02d/%04d\n",
                   paciente->dados[i].dataNascimento.tm_mday,
                   paciente->dados[i].dataNascimento.tm_mon + 1,
                   paciente->dados[i].dataNascimento.tm_year + 1900);
            printf("========================================================================================================================\n");

        }
    }

    if (pacientesEncontrados == 0)
    {
        printf("Nenhum paciente encontrado com o tipo sanguineo %s.\n", tipoSanguineo);
    }
}

// Função para imprimir pacientes com um determinado tipo sanguíneo
void imprimirPacientesPorCodigo(const struct VetorDinamico *paciente, const char *codigo)
{


    printf("---------------------------\n");
    printf("PACIENTE DO CODIGO %s:\n", codigo);
    printf("---------------------------\n");

    int pacientesEncontrados = 0;

    // Título
    printf("%-20s%-15s%-15s%-9s%-20s%-25s%-20s\n", "Nome", "RG", "CPF", "T.S", "Fator RH", "Endereco", "Codigo");
    printf("========================================================================================================================\n");

    for (int i = 0; i < paciente->tamanho; i++)
    {
        // Comparar tipos sanguíneos, ignorando maiúsculas/minúsculas
        if (strcasecmp(paciente->dados[i].codigo,  codigo) == 0)
        {
            pacientesEncontrados++;

            printf("%-20s%-15s%-15s%-9s%-20s%-25s%-20s\n",
                   paciente->dados[i].nome, paciente->dados[i].RG, paciente->dados[i].cpf,
                   paciente->dados[i].ts, paciente->dados[i].rh, paciente->dados[i].end,
                   paciente->dados[i].codigo);

            printf("Data Nascimento: %02d/%02d/%04d\n",
                   paciente->dados[i].dataNascimento.tm_mday,
                   paciente->dados[i].dataNascimento.tm_mon + 1,
                   paciente->dados[i].dataNascimento.tm_year + 1900);
            printf("========================================================================================================================\n");

        }
    }

    if (pacientesEncontrados == 0)
    {
        printf("Nenhum paciente encontrado com o codigo %s.\n",  codigo);
    }
}


// Função modificada para ordenar pacientes antes de imprimir
void imprimir_ordem(const struct VetorDinamico *paciente) {
    // Criar uma cópia dos dados dos pacientes
    struct paciente *copia_pacientes = malloc(paciente->tamanho * sizeof(struct paciente));
    if (copia_pacientes == NULL) {
        printf("Erro na alocação de memória para cópia dos pacientes.\n");
        exit(1);
    }

    memcpy(copia_pacientes, paciente->dados, paciente->tamanho * sizeof(struct paciente));

    // Ordenando a cópia do array de pacientes usando qsort e a função de comparação
    qsort(copia_pacientes, paciente->tamanho, sizeof(struct paciente), compararPacientes);

    // Título
    printf("%-20s%-15s%-15s%-9s%-20s%-25s%-20s\n", "Nome", "RG", "CPF", "T.S", "Fator RH", "Endereco", "Codigo");
    printf("========================================================================================================================\n");

    // Dados dos pacientes ordenados
    for (int i = 0; i < paciente->tamanho; i++) {
        printf("%-20s%-15s%-15s%-9s%-20s%-25s%-20s\n",
               copia_pacientes[i].nome, copia_pacientes[i].RG, copia_pacientes[i].cpf,
               copia_pacientes[i].ts, copia_pacientes[i].rh, copia_pacientes[i].end,
               copia_pacientes[i].codigo);

        printf("Data Nascimento: %02d/%02d/%04d\n",
               copia_pacientes[i].dataNascimento.tm_mday,
               copia_pacientes[i].dataNascimento.tm_mon + 1,
               copia_pacientes[i].dataNascimento.tm_year + 1900);
        printf("========================================================================================================================\n");
    }

    // Liberar a memória alocada para a cópia
    free(copia_pacientes);
}

char* lerCPF() {

    char* cpf = malloc(20);  // Aloca dinamicamente espaço para o CPF

    if (cpf == NULL) {
        printf("Erro na alocação de memória para CPF.\n");
        exit(1);
    }

    printf("=====================================\n");
    printf("Insira o CPF do paciente: \n");
    printf("=====================================\n");
    fgets(cpf, 20, stdin);
    cpf[strcspn(cpf, "\n")] = '\0';

    return cpf;
}
void excluirPacientePorCodigo(struct VetorDinamico *paciente, const char *codigo){
    int indice = -1;
    //Encontra o codigo do paciente com base no codigo
    for(int i = 0;i < paciente->tamanho;i++){
        if(paciente->dados[i].codigo != NULL && strcmp(codigo,paciente->dados[i].codigo) == 0){
            indice = i;
            break;
        }
    }
    if(indice == -1){
        printf("PACIENTE COM CÓDIGO %s NÃO ENCONTRADO\n",codigo);
    }

    else{
        //libera a memoria alocada para o paciente excluido
        liberarPaciente(&paciente->dados[indice]);
        //desloca os pacientes a direita do paciente excluido para preencher o espaço
        for (int i = indice; i < paciente->tamanho -1; ++i) {
            paciente->dados[i] = paciente->dados[i + 1];

        }
        //reduz o tamanho do vetor dinamico
        paciente->tamanho--;
        printf("PACIENTE COM CÓDIGO %s EXCLUÍDO COM SUCESSO!\n",codigo);

    }

}

int verificaCodigoPaciente(const struct VetorDinamico *paciente, const char *codigo)
{

    int pacientesEncontrados = 0;



    for (int i = 0; i < paciente->tamanho; i++)
    {
        if (strcasecmp(paciente->dados[i].codigo,  codigo) == 0)
        {
            pacientesEncontrados++;
        }
    }

    if (pacientesEncontrados == 0)
    {
        return 4;
    }
    return 0;
}

// Função para verificar se a string contém apenas letras
int contemApenasLetras(const char *str) {
    for (size_t i = 0; i < strlen(str); ++i) {
        if (!isalpha((unsigned char)str[i])) {
            return 0;  // A string contém pelo menos um caractere que não é uma letra
        }
    }
    return 1;  // A string contém apenas letras
}


// Função para verificar se a string contém apenas números
int contemApenasNumeros(const char *str) {
    while (*str) {
        if (!isdigit((unsigned char)*str)) {
            return 0;  // A string contém pelo menos um caractere não numérico
        }
        ++str;
    }
    return 1;  // A string contém apenas números
}
