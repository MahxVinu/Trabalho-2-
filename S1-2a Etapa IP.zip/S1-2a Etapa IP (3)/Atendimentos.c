#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "Atendimentos.h"
#include "pacientes.h"
void limparbuffer()
{
    int c;
    // O loop remove tods os caracteres ate encontrar uma quebra de linha ou  final do arquivo.
    while ((c = getchar()) != '\n' && c != EOF);
}


void listarAtendimentos(Lista list) {
    int i = 1;
    Atendimento *lista = list.inicio;

    printf("\nATENDIMENTOS CADASTRADOS:\n");
    printf("+---------------------------------------------------------------------------------------------+\n");
    printf("| No. | Código Atendimento | Código Paciente |   Tipo   |    Status    |   Preço   |    Data    |\n");
    printf("+---------------------------------------------------------------------------------------------+\n");

    while (lista) {
        struct tm *info_tempo;
        info_tempo = localtime(&lista->data_atendimentos);

        printf("| %-3d | %-18d | %-15d | %-8s | %-12s | $%-9.2f | %.2d/%.2d/%d |\n",
               i, lista->codigoA, lista->codigoP, lista->tipo, lista->status, lista->preco,
               info_tempo->tm_mday, info_tempo->tm_mon + 1, info_tempo->tm_year + 1900);

        lista = lista->proximo;
        ++i;
    }

    printf("+---------------------------------------------------------------------------------------------+\n");
}


Atendimento* ExcluirAtendimento(Lista *lista,int codA){
    Atendimento *aux, *remover = NULL;

    if(lista ->inicio){
        if( lista->inicio->codigoA == codA ){
            remover = lista->inicio;
            lista->inicio = remover ->proximo;
            lista->tam--;
        }
        else{
            aux = lista->inicio;
            while (aux ->proximo && aux ->proximo ->codigoA != codA) {
                aux = aux->proximo;
            }
            if(aux ->proximo){
                remover = aux ->proximo;
                aux ->proximo = remover ->proximo;
                lista->tam--;
            }
            else{
                printf("\nCÓDIGO DE ATENDIMENTO NÃO ENCONTRADO!\n");
            }

        }

    }
    return remover;
}


void imprimir_por_codigoP(Lista *lista, int cod) {
    Atendimento *aux;
    aux = lista->inicio;
    int encontrado = 0;

    printf("\nATENDIMENTOS DO PACIENTE COM CÓDIGO %d:\n", cod);
    printf("+---------------------------------------------------------------------------------------------+\n");
    printf("| Codigo Atendimento | Codigo Paciente |   Tipo   |    Status    |   Preco   |    Data    |\n");
    printf("+---------------------------------------------------------------------------------------------+\n");

    while (aux) {
        if (aux->codigoP == cod) {
            struct tm *info_tempo;
            info_tempo = localtime(&aux->data_atendimentos);

            printf("| %-18d | %-15d | %-8s | %-12s | $%-9.2f | %.2d/%.2d/%d |\n",
                   aux->codigoA, aux->codigoP, aux->tipo, aux->status, aux->preco,
                   info_tempo->tm_mday, info_tempo->tm_mon + 1, info_tempo->tm_year + 1900);

            encontrado = 1;
        }
        aux = aux->proximo;
    }

    printf("+---------------------------------------------------------------------------------------------+\n");

    if (!encontrado) {
        printf("NENHUM ATENDIMENTO ENCONTRADO PARA O PACIENTE COM CÓDIGO %d.\n", cod);
    }
}


void imprimir_por_codigoA(Lista *lista, int cod) {
    Atendimento *aux;
    aux = lista->inicio;
    int encontrado = 0;

    printf("\nATENDIMENTOS COM CÓDIGO %d:\n", cod);
    printf("+---------------------------------------------------------------------------------------------+\n");
    printf("| Codigo Atendimento | Codigo Paciente |   Tipo   |    Status    |   Preco   |    Data    |\n");
    printf("+---------------------------------------------------------------------------------------------+\n");

    while (aux) {
        if (aux->codigoA == cod) {
            struct tm *info_tempo;
            info_tempo = localtime(&aux->data_atendimentos);

            printf("| %-18d | %-15d | %-8s | %-12s | $%-9.2f | %.2d/%.2d/%d |\n",
                   aux->codigoA, aux->codigoP, aux->tipo, aux->status, aux->preco,
                   info_tempo->tm_mday, info_tempo->tm_mon + 1, info_tempo->tm_year + 1900);

            encontrado = 1;
            break;
        }
        aux = aux->proximo;
    }

    printf("+---------------------------------------------------------------------------------------------+\n");

    if (!encontrado) {
        printf("NENHUM ATENDIMENTO ENCONTRADO COM CÓDIGO %d.\n", cod);
    }
}


Atendimento* alterarAtendimento(Lista *lista,int codA){
    Atendimento *aux, *alterar = NULL;
    int dia,mes,ano;
    int opcao;
    if(lista ->inicio) {
        if (lista->inicio->codigoA == codA) {
            alterar = lista->inicio;
        }
        else {
            aux = lista->inicio;
            while (aux->proximo && aux->proximo->codigoA != codA ) {
                aux = aux->proximo;
            }
            if (aux->proximo) {
                alterar = aux ->proximo;
            }
        }
        if (alterar) {
            do {
                printf("\n\t0 - SAIR\n\t1 - ALTERAR STATUS\n\t2 - ALTERAR TIPO\n\t3 - ALTERAR DATA\n\t4 - ALTERAR PREÇO\n");
                scanf("%d", &opcao);
                limparbuffer();
                if( (opcao > 0) && (opcao < 5) )
                    alterar->alterado = 1;

                switch (opcao) {
                    case ALTERAR_STATUS:
                        inserir_status(alterar);
                        break;
                    case ALTERAR_TIPO:
                        inserir_tipo(alterar);
                        break;
                    case ALTERAR_DATA:
                        //Solicitar ao usuario a nova data
                        printf("INSIRA A NOVA DATA:\n");
                        scanf("%d/%d/%d",&dia,&mes,&ano);
                        limparbuffer();
                        //Cria uma estrutura tm para reopresentar a nova data
                        struct  tm data_nova = {0};
                        data_nova.tm_year = ano - 1900;
                        data_nova.tm_mon = mes - 1;
                        data_nova.tm_mday = dia;
                        //Converter a struct tm para time_t
                        time_t novo_tempo = mktime(&data_nova);
                        //Atualizar o campo data_atendimento
                        alterar->data_atendimentos = novo_tempo;
                        break;
                    case ALTERAR_PRECO:
                        printf("INSIRA O PREÇO NOVO:\n");
                        scanf("%f", &alterar->preco);
                        limparbuffer();
                        break;
                    case SAIR_ALTERAR:
                        break;

                    default:
                        printf("\nOPÇÃO INVÁLIDA!\n");

                        break;
                }
            } while (opcao);

        }
    }

    return alterar;

}

void Soma_precoConsultasP(Lista *lista,int cod){
    float soma = 0;
    Atendimento *aux = lista->inicio;
    printf("\nPACIENTE COM CÓDIGO %d:\n", cod);
    printf("+---------------------------------------------------------------------------------------------+\n");
    printf("| Codigo Atendimento | Codigo Paciente |   Tipo   |    Status    |   Preco   |    Data    |\n");
    printf("+---------------------------------------------------------------------------------------------+\n");
    while(aux){
        if(aux->codigoP == cod){
            struct tm *info_tempo;
            info_tempo = localtime(&aux->data_atendimentos);
            printf("| %-18d | %-15d | %-8s | %-12s | $%-9.2f | %.2d/%.2d/%d |\n",aux->codigoA,aux->codigoP,aux->tipo,aux->status,aux->preco,info_tempo->tm_mday,info_tempo->tm_mon + 1,info_tempo->tm_year + 1900);
            soma += aux->preco;
        }
        aux = aux->proximo;

    }
    printf("+---------------------------------------------------------------------------------------------+\n");
    if(soma) {
        printf("\nCÓDIGO DO PACIENTE: %d\t SOMA DAS CONSULTAS PAGAS: $%.2f\n ", cod, soma);
    }
    else{
        printf("CÓDIGO NÃO ENCONTRADO!\n");
    }


}

void controle(Lista list){
    Atendimento *lista = list.inicio;
    while (lista) {
        lista->alterado = 0;
        lista =lista->proximo;
    }
}

void salvar(Lista *lista, char arq[]) {
    FILE *file = fopen(arq, "wb");
    if (file) {
        Atendimento *salvar = lista->inicio;
        while (salvar) {
            if (salvar->alterado == 1) {
                fseek(file, ftell(file), SEEK_SET); // Posiciona o cursor para sobrescrever o registro
                fwrite(salvar, sizeof(Atendimento), 1, file);
            }
            else if (salvar->alterado != 3) {
                fseek(file, 0, SEEK_END); // Posiciona o cursor no final do arquivo para novos registros
                fwrite(salvar, sizeof(Atendimento), 1, file);
            }
            salvar = salvar->proximo;
        }
        fclose(file);
    } else {
        printf("\nERRO AO SALVAR O ARQUIVO\n");
        exit(1);
    }
}




void carregar_lista(Lista *lista, char arq[]) {
    Atendimento atnd;
    FILE *file = fopen(arq, "rb+");

    if(!file){
        printf("\nO ARQUIVO PODE ESTAR SENDO ABERTO PELA PRIMEIRA VEZ\n");
        file = fopen(arq,"wb");
        if(!file){
            printf("\nERRO AO ABRIR O ARQUIVO\n");
            exit(1);
        }

    }
    lista->inicio = NULL;
    lista->tam = 0;
    Atendimento *aux = NULL;
    while (fread(&atnd, sizeof(Atendimento), 1, file) == 1) {
        Atendimento *novo = (Atendimento *)malloc(sizeof(Atendimento));
        if (!novo) {
            printf("\nERRO DE ALOCAÇÃO DE MEMÓRIA\n");
            exit(1);
        }
        memcpy(novo, &atnd, sizeof(Atendimento));
        novo->proximo = NULL;

        if (lista->inicio == NULL) {
            lista->inicio = novo;
            aux = novo;
        }
        else {

            aux->proximo = novo;
            aux = aux->proximo;
        }
        lista->tam++;

    }
    fclose(file);
}

int verifica_CodA(int codA,Lista *lista){
    Atendimento *verificador = lista->inicio;
    while (verificador){
        if(verificador->codigoA == codA)
            return 1;
        verificador = verificador->proximo;
    }

    return 0;
}
int gerador(){
    int cod;
    srand(time(NULL));
    cod = rand()%10000;
    return cod;
}

void inserir_tipo(Atendimento *atendimento){
    int opcao;
    printf("\n\t1 - CONSULTA\n\t2 - RETORNO\n");
    scanf("%d",&opcao);
    limparbuffer();
    while(1){
        if(opcao == 1 || opcao == 2){
            break;
        }
        scanf("%d",&opcao);
        limparbuffer();
    }
    switch (opcao) {
        case CONSULTA:
            strcpy(atendimento->tipo,"Consulta");
            break;
        case RETORNO:
            strcpy(atendimento->tipo,"Retorno");
            break;
    }
}
void inserir_status(Atendimento *atendimento) {
    int escolha;
    char buffer[256];  // Buffer para armazenar a entrada do usuário

    printf("\n\t1 - AGENDADO\n\t2 - ESPERANDO\n\t3 - EM ATENDIMENTO\n\t4 - ATENDIDO\n");

    // Obtém a entrada do usuário e armazena em buffer
    fgets(buffer, sizeof(buffer), stdin);

    // Se o usuário pressionar Enter, atribua um status vazio
    if (buffer[0] == '\n') {
        strcpy(atendimento->status, "");
        return;
    }

    // Converte a entrada para um número inteiro
    escolha = atoi(buffer);

    // Enquanto a escolha não estiver nos valores válidos, continue pedindo ao usuário
    while (escolha != AGENDADO && escolha != ESPERANDO && escolha != EM_ATENDIMENTO && escolha != ATENDIDO) {
        printf("Escolha inválida. Tente novamente: ");
        fgets(buffer, sizeof(buffer), stdin);
        escolha = atoi(buffer);
    }

    // Atribui o status correspondente à escolha do usuário
    switch (escolha) {
        case AGENDADO:
            strcpy(atendimento->status, "Agendado");
            break;
        case ESPERANDO:
            strcpy(atendimento->status, "Esperando");
            break;
        case EM_ATENDIMENTO:
            strcpy(atendimento->status, "Em atendimento");
            break;
        case ATENDIDO:
            strcpy(atendimento->status, "Atendido");
            break;
    }
}
int consultaMarcadaNaData(Lista *lista,int codPaciente,time_t dataConsulta){
    Atendimento *aux = lista->inicio;
    while(aux){
        if(aux->codigoP == codPaciente && aux->data_atendimentos == dataConsulta){
            return 2;
        }
        aux = aux->proximo;
    }
    return 0;
}

void imprimirPorOrdemData(Lista *lista) {
    //Criar um array para armazenar os ponteiros para os atendimentos
    Atendimento **atendimentos = (Atendimento **) malloc(lista->tam * sizeof(Atendimento *));

    if(atendimentos == NULL){
        printf("ERRO AO ALOCAR MEMÓRIA\n");
        exit(1);
    }
    // preencher o array com os ponteiros para atendimento
    Atendimento *aux = lista->inicio;
    int i = 0;
    while (aux) {
        atendimentos[i] = aux;
        aux = aux->proximo;
        i++;
    }

    //ordenar usando bubble sort
    for (int j = 0; j < lista->tam - 1; ++j) {
        for (int k = 0; k < lista->tam - j - 1; ++k) {
            if (difftime(atendimentos[k]->data_atendimentos, atendimentos[k + 1]->data_atendimentos) > 0) {
                Atendimento *temp = atendimentos[k];
                atendimentos[k] = atendimentos[k + 1];
                atendimentos[k + 1] = temp;
            }
        }
    }

    //imprimir os atendimentos ordenados por data
    printf("\n\tATENDIMENTOS POR ORDEM DE DATA:\t\t tam: %d \n",lista->tam);
    printf("+---------------------------------------------------------------------------------------------+\n");
    printf("| Codigo Atendimento | Codigo Paciente |   Tipo   |    Status    |   Preco   |    Data    |\n");
    printf("+---------------------------------------------------------------------------------------------+\n");
    for (int l = 0; l < lista->tam; ++l) {
        struct tm *info_tempo;
        info_tempo = localtime(&atendimentos[l]->data_atendimentos);

        printf("| %-18d | %-15d | %-8s | %-12s | $%-9.2f | %.2d/%.2d/%d |\n",
               atendimentos[l]->codigoA, atendimentos[l]->codigoP, atendimentos[l]->tipo, atendimentos[l]->status,
               atendimentos[l]->preco, info_tempo->tm_mday, info_tempo->tm_mon + 1, info_tempo->tm_year + 1900);


    }
    printf("-----------------------------------------------------------------------------------------------\n");
    free(atendimentos);
}

float soma_Preco_Por_Data(Lista *lista){
    int dia,mes,ano;
    float soma = 0.0f;
    printf("INFORME A DATA PARA SOMAR AS CONSULTAS (DD/MM/AAAA):\n");
    scanf("%d/%d/%d",&dia,&mes,&ano);
    limparbuffer();


    //Cria uma estrutura tm para representar a dat informada
    struct tm dataProcurada = {0};
    dataProcurada.tm_year = ano - 1900;
    dataProcurada.tm_mon = mes - 1;
    dataProcurada.tm_mday = dia;

    //converte a struct tm para time_t
    time_t dataInformada = mktime(&dataProcurada);
    Atendimento *aux = lista->inicio;
    printf("\n\tATENDIMENTOS REALIZADOS EM %.2d/%.2d/%d\n",dia,mes,ano);
    printf("| Codigo Atendimento | Codigo Paciente |   Tipo   |    Status    |   Preco   |    Data    |\n");
    printf("+---------------------------------------------------------------------------------------------+\n");
    while(aux){
        //Verifica se a data do atendimento é igual a data informada

        if( difftime(aux->data_atendimentos,dataInformada) == 0){
            soma += aux->preco;
            //Converter o time_tpara uma estrutura de tempo(struct tm)
            struct tm *info_tempo;
            info_tempo = localtime(&aux->data_atendimentos);
            printf("| %-18d | %-15d | %-8s | %-12s | $%-9.2f | %.2d/%.2d/%d |\n",
                   aux->codigoA, aux->codigoP, aux->tipo, aux->status, aux->preco,info_tempo->tm_mday,info_tempo->tm_mon + 1,info_tempo->tm_year + 1900);
            printf("\n------------------------------------------------------------------------------------------\n");

        }
        aux = aux->proximo;
    }
    return soma;
}

void soma_consultas_em_intervalo(Lista *lista){
    int diaI, mesI, anoI, diaF, mesF, anoF, encontrados = 0;
    float soma = 0.0f;
    printf("\n\tINSIRA A DATA INICIAL DO INTERVALO (DD/MM/AAAA):\n");
    scanf("%d/%d/%d",&diaI,&mesI,&anoI);
    limparbuffer();
    //Cria uma estrutura tm para representar a data informada
    struct tm dataI = {0};
    dataI.tm_year = anoI - 1900;
    dataI.tm_mon = mesI - 1;
    dataI.tm_mday = diaI;
    //Converte as structs para time_t
    time_t data_inicial = mktime(&dataI);

    printf("\n\tINSIRA A DATA FINAL DO INTERVALO (DD/MM/AAAA):\n");
    scanf("%d/%d/%d",&diaF,&mesF,&anoF);
    limparbuffer();
    //Cria uma estrutura tm para representar a data informada
    struct tm dataF = {0};
    dataF.tm_year = anoF - 1900;
    dataF.tm_mon = mesF - 1;
    dataF.tm_mday = diaF;
    //Converte as structs para time_t
    time_t data_final = mktime(&dataF);

    Atendimento  *aux = lista->inicio;
    printf("\n\tATENDIMENTOS NO INTERVALO:\n");
    printf("| Codigo Atendimento | Codigo Paciente |   Tipo   |    Status    |   Preco   |    Data    |\n");
    printf("+---------------------------------------------------------------------------------------------+\n");
    while (aux){
        if(difftime(aux->data_atendimentos,data_inicial) >= 0 && difftime(data_final,aux->data_atendimentos) >= 0  ){
            struct tm *info_tempo;
            info_tempo = localtime(&aux->data_atendimentos);
            printf("| %-18d | %-15d | %-8s | %-12s | $%-9.2f | %.2d/%.2d/%d |\n",
                   aux->codigoA, aux->codigoP, aux->tipo, aux->status, aux->preco,info_tempo->tm_mday,info_tempo->tm_mon + 1,info_tempo->tm_year + 1900);
            soma += aux->preco;
            encontrados++;

        }
        aux = aux->proximo;
    }
    printf("\n------------------------------------------------------------------------------------------\n");

    if(encontrados){
        printf("\nSOMA DOS PREÇOS DAS CONSULTAS DENTRO DO INTERVALO: %.2f\n",soma);
    }
    else {
        printf("\nNENHUM ATENDIMENTO ENCONTRADO DENTRO DO INTERVALO INFORMADO!\n");
    }

    printf("\n------------------------------------------------------------------------------------------\n");
}

//Função para transformar codigo de paciente para char
const char *  transforma_cod_para_string(int codigo){
    char *str = (char *) malloc(sizeof(char) * 20);
    if(str == NULL){
        printf("ERRO DE ALOCAÇAO\n");
        exit(1);
    }
    //Converte o codigo para string
    snprintf(str,20,"%d",codigo);
    return str;

}



void Pacientes_com_consulta_naData(Lista *lista,const struct VetorDinamico *paciente){
    int dia,mes,ano;

    //pede a data para buscar as consultas
    printf("INFORME A DATA PARA BUSCAR OS PACIENTES COM CONSULTA (DD/MM/AAAA):\n");
    scanf("%d/%d/%d",&dia,&mes,&ano);
    limparbuffer();

    //Cria uma estrutura tm para representar a data informada
    struct tm data_procurada = {0};
    data_procurada.tm_year = ano - 1900;
    data_procurada.tm_mon = mes - 1;
    data_procurada.tm_mday = dia;

    // converte para time_t
    time_t datainformada = mktime(&data_procurada);

    //Percorre a lista de atendimentos
    Atendimento  *aux = lista->inicio;
    printf("\n\tPACIENTES COM CONSULTA EM %.2d/%.2d/%d\n",dia,mes,ano);
    printf("\n------------------------------------------------------------------------------------------\n");

    //Percorrer a lista de atendimentos
    while (aux){
        if( difftime(aux->data_atendimentos,datainformada) == 0){
            imprimirPacientesPorCodigo(paciente,transforma_cod_para_string(aux->codigoP));

        }
        aux = aux->proximo;
    }

}



void ExcluirAtendimentoPorCodP(Lista *lista,int codP) {
    Atendimento *aux, *remover;
    while (lista->inicio && lista->inicio->codigoP == codP) {
        remover = lista->inicio;
        lista->inicio = remover->proximo;
        lista->tam--;
        free(remover);
    }


    if (lista->inicio) {
        aux = lista->inicio;
        while(aux->proximo){
            if(aux->proximo->codigoP == codP){
                remover = aux->proximo;
                aux->proximo = remover->proximo;
                lista->tam--;
                free(remover);
            }
            else{
                aux = aux->proximo;
            }
        }

    }
}











