#ifndef TRABALHO_2ETAPA_ATENDIMENTO_H
#define TRABALHO_2ETAPA_ATENDIMENTO_H


#include "pacientes.h"







typedef struct Atendimento{
    int codigoA;
    int codigoP;
    char tipo[20];
    char status[20];
    float preco;
    time_t data_atendimentos;
    int alterado;
    struct Atendimento *proximo;
}Atendimento;

typedef struct{
    Atendimento *inicio;
    int tam;
}Lista;
typedef enum{
    SAIR_ALTERAR,
    ALTERAR_STATUS,
    ALTERAR_TIPO,
    ALTERAR_DATA,
    ALTERAR_PRECO
}Alterar_opcoes;

typedef enum {
    AGENDADO = 1,
    ESPERANDO,
    EM_ATENDIMENTO,
    ATENDIDO,
}status;
typedef  enum {
    CONSULTA = 1,
    RETORNO
}Tipo_Atendimento;



int menuAtendimento();

void listarAtendimentos(Lista list);
Atendimento* ExcluirAtendimento(Lista *lista,int codA);
void imprimir_por_codigoP(Lista *lista,int cod);
void imprimir_por_codigoA(Lista *lista,int cod);
Atendimento* alterarAtendimento(Lista *lista,int codA);
void Soma_precoConsultasP(Lista *lista,int cod);
void controle(Lista list);
void salvar(Lista *lista,char arq[]);
void carregar_lista(Lista *lista, char arq[]);
int verifica_CodA(int codA,Lista *lista);
int gerador();
void inserir_tipo(Atendimento *atendimento);
void inserir_status(Atendimento *atendimento);
int consultaMarcadaNaData(Lista *lista,int codPaciente,time_t dataConsulta);
void imprimirPorOrdemData(Lista *lista);
float soma_Preco_Por_Data(Lista *lista);
void soma_consultas_em_intervalo(Lista *lista);
void limparbuffer(void);
void Pacientes_com_consulta_naData(Lista *lista,const struct VetorDinamico *pacientes);
const char *transforma_cod_para_string(int codigo);

void ExcluirAtendimentoPorCodP(Lista *lista,int codP);
#endif //TRABALHO_2ETAPA_ATENDIMENTO_H
