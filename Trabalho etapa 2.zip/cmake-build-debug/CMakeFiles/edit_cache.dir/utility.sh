set -e

cd "/cygdrive/c/CLION/CLion 2023.2.2/S1-2a Etapa IP/S1-2a Etapa IP/cmake-build-debug"
/cygdrive/c/Users/55859/AppData/Local/JetBrains/CLion2023.2/cygwin_cmake/bin/cmake.exe -E echo No\ interactive\ CMake\ dialog\ available.
